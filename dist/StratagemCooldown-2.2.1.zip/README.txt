战备冷却 / Stratagem Cooldown 2.2.1

默认：只载具 80%。次数块作用于所有有限次数战备；飞鹰次数块只作用于 EAGLE.*。
