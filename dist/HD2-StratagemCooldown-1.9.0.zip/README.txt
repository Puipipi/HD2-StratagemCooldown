HD2 Stratagem Cooldown 1.9.0 - quick guide / 快速指南

What it does / 作用
  Shortens stratagem cooldowns by a percentage of each stratagem's OWN value
  (default 50%) and can change how many charges a limited stratagem has.
  按每条战备自己的原值乘以百分比缩短冷却（默认 50%），并可修改有限次数战备的次数。

Config / 配置
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\StratagemCooldown\config.txt
    percent=50             cooldown percentage (50 = halve; 0 = use cooldown_s)
    cooldown_s=390         fixed cooldown, only when percent=0
    uses_percent=100       charges percentage (100 = unchanged, 200 = double;
                           only affects stratagems that have a finite count)
    uses_fixed=0           fixed charge count (0 = off, overrides uses_percent)
    red=yes                red stratagems (offensive)
    orbital=yes              - ORBITAL. series
    eagle=yes                - EAGLE. series incl. EAGLE. REARM
    blue=yes               blue stratagems (support equipment)
    blue_scope=all           - vehicles | mechs | both | all
    green=yes              green stratagems (sentries, emplacements)
    missions=no            mission stratagems (reinforce/extraction/...) - off
    stable_s=1             pointer-stability window before writing
    uptime_s=0             write as soon as the records are valid
    probe=no               opt-in diagnostic memory search

Categories / 分类
  red   : ORBITAL. and EAGLE. (EAGLE. REARM is the real Eagle cycle: Eagle
          stratagems spend charges and one rearm restores them all, so its
          cooldown is what paces the family)
  blue  : TEAM WEAPONS. BACKPACK. CONSUMABLES., plus vehicles/mechs according
          to blue_scope (VEHICLES. tanks and FRV = vehicles, VEHICLES.
          COMBAT WALKER = mechs). blue_scope is mutually exclusive:
            就载具=vehicles  就机甲=mechs  就载具和机甲=both  全部=all
  green : SENTRYS. SENTRIES. EMPLACEMENTS.
  Charges: Orbital Laser 3, mechs 3, Eagle 1..4; -1 means unlimited and is
  never turned into a limit.
  次数：激光轨道 3、机甲 3、飞鹰 1..4；-1 表示无限，不会被改成有限。

Log / 日志
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\VehicleCooldown.log
  Healthy session: located -> installed -> mode=... -> records appeared ->
  patched offsets -> cooldown applied -> heartbeat every 60s.
  健康会话：定位 -> 安装 -> 模式 -> 发现记录 -> 写入偏移 -> 应用成功 -> 心跳。
