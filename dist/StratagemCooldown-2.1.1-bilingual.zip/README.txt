战备冷却 / Stratagem Cooldown 2.1.1

五块独立勾选 / five independent blocks；取消勾选＝不生效 (untick = disabled)。
冷却块携带核心 addon，必须勾选 / the cooldown block carries the core addon.
微调 / fine tuning: %LOCALAPPDATA%\CowboyBingus\Helldivers2\VehicleCooldown\config.txt
