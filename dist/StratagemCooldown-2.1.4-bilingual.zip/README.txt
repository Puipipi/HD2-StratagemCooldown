战备冷却 / Stratagem Cooldown 2.1.4

默认 / defaults：蓝战备＝就载具 + 冷却 80%；红/绿/次数默认关闭。
