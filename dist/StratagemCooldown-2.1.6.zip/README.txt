战备冷却 / Stratagem Cooldown 2.1.6

开箱默认：只作用于载具（坦克/FRV）、保留 80%。
每块只勾一项；默认项都是第一项（红=关闭、绿=关闭、次数=不添加）。
要 50%：在 config.txt 里启用 percent=50。
