战备冷却 / Stratagem Cooldown 2.1.2

五块独立勾选；取消勾选＝不生效。冷却块携带核心 addon，必须勾选。
