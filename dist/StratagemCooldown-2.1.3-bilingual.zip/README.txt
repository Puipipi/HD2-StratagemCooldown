战备冷却 / Stratagem Cooldown 2.1.3

默认设置 / defaults：蓝战备＝就载具（坦克与 FRV）+ 冷却 80%；红战备、绿战备、次数增加默认关闭。
想改动就在管理器里勾选；取消勾选＝不生效。
微调 / fine tuning: %LOCALAPPDATA%\CowboyBingus\Helldivers2\VehicleCooldown\config.txt
