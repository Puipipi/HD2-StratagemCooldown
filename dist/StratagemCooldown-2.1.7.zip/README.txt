战备冷却 / Stratagem Cooldown 2.1.7

默认：只载具、80%。次数与颜色范围无关。
