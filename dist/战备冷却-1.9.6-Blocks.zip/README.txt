战备冷却 1.9.6

五个独立块（每块勾选一项，不勾＝不修改该块）：
- 红战备 / Red（勾选＝开启，取消勾选＝不改红战备）：轨道 + 飞鹰 / orbital + eagle | 只轨道 / orbital only | 只飞鹰 / eagle only
- 蓝战备 / Blue（勾选＝开启，取消勾选＝不改蓝战备）：全部 / all | 就载具 / vehicles only | 就机甲 / mechs only | 就载具和机甲 / vehicles + mechs
- 绿战备 / Green（整块勾选＝开启；哨戒、炮台、地雷、护盾、特斯拉）：整块勾选
- 冷却时间 / Cooldown（核心块，必须勾选）：50% —— 减半 / half | 80% —— 减少 20% / 20% shorter | 100% —— 不减少 / unchanged
- 次数增加 / Charges（取消勾选＝不改次数）：+1 次 / +1 charge | +2 次 / +2 charges | +3 次 / +3 charges | 去除数量限制 / unlimited
冷却块携带核心组件，必须保持勾选。
