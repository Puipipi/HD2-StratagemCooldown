战备冷却 1.9.6

五个独立块（每块勾选一项；不勾＝不修改该块）：

红战备 / Red（勾选＝开启，取消勾选＝不改红战备）
  - 轨道 + 飞鹰 / orbital + eagle：两系都改。飞鹰以返回补给 EAGLE. REARM 的冷却为准。
  - 只轨道 / orbital only：仅 ORBITAL. 系列。
  - 只飞鹰 / eagle only：仅 EAGLE. 系列（含返回补给）。

蓝战备 / Blue（勾选＝开启，取消勾选＝不改蓝战备）
  - 全部 / all：支援武器、背包、补给 + 载具 + 机甲。
  - 就载具 / vehicles only：坦克与 FRV。
  - 就机甲 / mechs only：COMBAT WALKER 机甲四型。
  - 就载具和机甲 / vehicles + mechs：载具与机甲，不含支援武器/背包。

绿战备 / Green（整块勾选＝开启；哨戒、炮台、地雷、护盾、特斯拉）
  - 开启 / on：哨戒机炮/迫击炮、炮台、地雷（反步兵/燃烧/反坦克）、护盾发生器等。

冷却时间 / Cooldown（核心块，必须勾选）
  - 50% —— 减半 / half：所有已勾选类别按各自原值减半。
  - 80% —— 减少 20% / 20% shorter：保留 80%。
  - 100% —— 不减少 / unchanged：冷却不变，只在次数块有改动时才有效果。

次数增加 / Charges（取消勾选＝不改次数）
  - +1 次 / +1 charge：每条有限次数战备 +1。
  - +2 次 / +2 charges：每条有限次数战备 +2。
  - +3 次 / +3 charges：每条有限次数战备 +3。
  - 去除数量限制 / unlimited：有限次数改成无限（-1）；原本无限的不动。

冷却块携带核心组件，必须保持勾选。
微调：%%LOCALAPPDATA%%\CowboyBingus\Helldivers2\VehicleCooldown\config.txt
