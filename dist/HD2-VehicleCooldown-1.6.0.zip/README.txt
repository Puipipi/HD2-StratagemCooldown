HD2 Vehicle Cooldown 1.6.0 - quick guide / 快速指南

What it does / 作用
  Shortens the redeploy cooldown of every stratagem vehicle (tanks, exos,
  FRV). Default target: 390 s instead of the vanilla 780 s.
  缩短所有载具战略配备（坦克、机甲、FRV）的重新部署冷却，默认 390 秒（原版 780 秒）。

Requirements / 依赖
  Bingus Shared Loader v15+ (API 1). Enable both and deploy.
  需要 Bingus Shared Loader v15+（API 1），两个都要启用并部署。
  Do not run Tank Cooldown v2 next to this one: both write the same field.
  不要与 Tank Cooldown v2 同时启用，两者写同一个字段。

Config / 配置
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\VehicleCooldown\config.txt
    cooldown=yes|no      feature switch (default yes)
    cooldown_s=390       target cooldown in seconds (vanilla 780)
    stable_s=6           pointer-stability window before any write
    uptime_s=60          minimum process uptime before the first write
  The file is created on first run; edit it and restart the game.
  首次运行自动生成；改完需重启游戏。uptime_s 越大越保守。

Log / 日志
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\VehicleCooldown.log
  A healthy session shows, in order:
    table located at load -> v1.6.0 installed -> uptime gate passed
    -> vehicle records appeared: N target(s) -> cooldown applied to N ...
    -> heartbeat every 60 s (state / targets / errors)
  正常一次会话依次出现：定位成功、安装、通过开机门槛、发现记录、写入成功，
  之后每 60 秒一条心跳（状态/目标数/错误数）。
  "no vehicle records yet" means the table is readable but no vehicle record
  matched (wrong game build, or the field moved) - the log then prints the
  counters: slots / records / matched / rejects / contained_faults.
  出现 no vehicle records yet 表示表可读但没有匹配到载具记录，日志会同时给出计数。

1.6.0 fixed three real defects of 1.5.x (see the header of this file):
  the table base was stored in a shadowing local (every scan died on a nil
  upvalue), the stability gate's self signature was wrong, and the 146-slot
  sweep followed unvalidated pointers. Any unexpected error is now logged
  and counted in M.errors / M.last_error instead of disappearing.
  1.6.0 修掉 1.5.x 的三个真实缺陷：表基址被同名局部变量遮蔽（每次扫描都因
  nil 上值中断）、稳定门槛的自参数签名错误、146 槽扫描跟随未校验指针；
  现在任何异常都会写日志并计入 M.errors / M.last_error，不再静默消失。

This guide is shipped inside the package as README.txt. It is generated from
this comment block by work/standalone/build_vc.py, so it can never drift.
本指南由构建脚本从源码注释生成，与代码不会脱节。
