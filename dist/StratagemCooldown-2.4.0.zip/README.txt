战备冷却 / Stratagem Cooldown 2.4.0
====================

开箱默认 / Defaults
  只作用于载具（坦克、FRV），冷却保留 80%。不做任何设置就是这样。
  Vehicles only (tanks, FRV) at 80% - no setup needed.

怎么配置 / How to configure
  1) 双击 config-builder.html（浏览器打开），勾选六块 → 复制生成的文本
  2) 粘贴到：%LOCALAPPDATA%\CowboyBingus\Helldivers2\VehicleCooldown\config.txt
  3) 重启游戏生效
  Or edit that config.txt by hand - the format is:
     [cooldown] percent=80
     [scope]    red=off|orbital|eagle|both   blue=off|vehicles|mechs|both|all   green=on|off
     [charges]  mode=none|+1|+2|+3|unlimited      (机甲、轨道激光等；飞鹰不受影响)
     [eagle]    mode=none|+1|+2|+3                (只作用于 EAGLE.*)
  旧的平铺写法（percent=50 / red=yes / blue_scope=all / uses_unlimited=yes）同样有效。

安装 / Install
  把 ZIP 导入 Arsenal 或 HD2MM（或手动解压到游戏目录），并确保装了 Bingus Shared Loader。
  Import the ZIP in Arsenal or HD2MM (or unpack it manually) with Bingus Shared Loader.

注意 / Notes
  飞鹰的“无限”会被游戏识别为“次数耗尽”，所以飞鹰只提供 +1/+2/+3。
  飞鹰的恢复节奏由「返回补给 EAGLE. REARM」的冷却决定（50% 档位：150 秒 → 75 秒）。
