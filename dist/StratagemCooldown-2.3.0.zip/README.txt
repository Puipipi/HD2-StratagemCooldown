战备冷却 / Stratagem Cooldown 2.3.0

默认：只载具 80%。非管理器环境可用 config.txt（percent / uses_unlimited / red / blue ...）。
