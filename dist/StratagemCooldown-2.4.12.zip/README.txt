战备冷却 / Stratagem Cooldown 2.4.1
====================

开箱默认 / Defaults
  只作用于载具（坦克、FRV），冷却保留 80%。不做任何设置就是这样。
  Vehicles only (tanks, FRV) at 80% - no setup needed.

配置 / Configure
  1) 用浏览器打开 config-builder.html，勾选六块 → 复制生成的文本
  2) 粘贴到：%LOCALAPPDATA%\CowboyBingus\Helldivers2\VehicleCooldown\config.txt
  3) 重启游戏
  也可以手写该文件（注释行用 ; 或 #，未注释的键生效）：
     cooldown=yes        总开关
     percent=80          冷却保留百分比（80 或 50）
     red=yes|no          红战备（轨道 + 飞鹰）
     orbital=yes|no      只控制轨道系（与 eagle 配合可只开一系）
     eagle=yes|no        只控制飞鹰系（含返回补给 REARM）
     blue=yes|no         蓝战备
     blue_scope=vehicles|mechs|both|all
     green=yes|no        绿战备（哨戒/炮台/地雷/特斯拉/护盾）
     uses_add=0|1|2|3    次数增加（机甲、轨道激光等有限次数战备）
     uses_unlimited=yes  次数改为无限（-1）
     eagle_uses_add=0|1|2|3   飞鹰专用次数增加（飞鹰不要设无限）

安装 / Install
  把 ZIP 导入 Arsenal 或 HD2MM，或手动解压到游戏目录；需要 Bingus Shared Loader。

注意 / Notes
  飞鹰的“无限”会被游戏识别成“次数耗尽”（显示不可用），所以飞鹰只提供 +1/+2/+3；
  飞鹰的恢复节奏由「返回补给 EAGLE. REARM」的冷却决定（50% 档：150 秒 → 75 秒）。

日志 / Log
  配置文件的旁边有日志：%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\VehicleCooldown.log
  第二行会写明读到了什么，例如：
    blocks(from manager DB): red=no blue=vehicles | explicit: config.txt: percent=80 | effective: percent=80 red=false(orbital=false,eagle=false) blue=true(vehicles) green=false uses_add=0 uses_unlimited=false
  第三行 cooldown applied to ... 是实际写入的数值。出问题时把这两行发出来即可定位。
