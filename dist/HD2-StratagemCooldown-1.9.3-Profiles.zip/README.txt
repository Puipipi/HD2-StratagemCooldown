HD2 Stratagem Cooldown 1.9.3

In Arsenal, open this mod and pick ONE entry under "方案 / Profile".
Each profile is a complete build (same addon GUID), so exactly one deploys.

Fine tuning: %LOCALAPPDATA%\CowboyBingus\Helldivers2\VehicleCooldown\config.txt
Uncomment a key to override whatever the profile set.

- 标准：全部战备 50% / Standard: everything at 50%: Tank 780->390, FRV 480->240, mech 420->210, orbital/eagle/sentries half. Charges untouched.
- 全部战备 50% + 数量+1 / everything 50%, +1 charge: As Standard, plus one extra charge on every limited stratagem.
- 全部战备 50% + 数量+2 / everything 50%, +2 charges: As Standard, plus two extra charges on every limited stratagem.
- 全部战备 50% + 数量+3 / everything 50%, +3 charges: As Standard, plus three extra charges on every limited stratagem.
- 全部战备 50% + 去除数量限制 / everything 50%, unlimited charges: As Standard, and every limited stratagem (Eagle, Orbital Laser, mechs) becomes unlimited.
- 全部战备 80%（减少20%）/ everything at 80%: Tank 780->624, FRV 480->384, mech 420->336. Charges untouched.
- 全部战备 80% + 去除数量限制 / everything 80%, unlimited charges: Cooldowns at 80% and no charge limits.
- 只改数量（冷却不动）/ charges only: Cooldowns untouched, every limited stratagem becomes unlimited.
- 只红战备 50% / red only (orbital + eagle): ORBITAL. and EAGLE.; EAGLE. REARM 150->75 is the real Eagle cycle.
- 只蓝战备 50% / blue only: Support weapons, backpacks, resupply, plus vehicles and mechs.
- 只绿战备 50% / green only: Sentries and emplacements.
- 只载具和机甲 50% / vehicles and mechs only: Tanks, FRV, mechs at 50%; nothing else changes.
