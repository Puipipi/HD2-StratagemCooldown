HD2 Stratagem Cooldown 1.9.4

Five independent blocks (tick one entry per block):

红战备 / Red
  - 关闭 / off: 不修改红战备。
  - 轨道 + 飞鹰 / orbital + eagle: 取消勾选可整块关闭。飞鹰以返回补给 EAGLE. REARM 的冷却为准。
  - 只轨道 / orbital only: 仅 ORBITAL. 系列。
  - 只飞鹰 / eagle only: 仅 EAGLE. 系列（含返回补给）。

蓝战备 / Blue
  - 全部 / all: 支援武器、背包、补给 + 载具 + 机甲。
  - 就载具 / vehicles only: 坦克与 FRV。
  - 就机甲 / mechs only: COMBAT WALKER 机甲四型。
  - 就载具和机甲 / vehicles + mechs: 载具与机甲，不含支援武器/背包。
  - 关闭 / off: 不修改蓝战备。

绿战备 / Green
  - 开启 / on: 哨戒机炮与炮台/固定武器。
  - 关闭 / off: 不修改绿战备。

冷却时间 / Cooldown
  - 50% —— 减半 / half: 核心块：所有被勾选类别按各自原值减半。
  - 80% —— 减少 20% / 20% shorter: 核心块：保留 80%。
  - 100% —— 不减少 / unchanged: 核心块：冷却不变，只在次数块有改动时才有效果。

次数增加 / Charges
  - 不变 / unchanged: 不改次数。
  - +1 次 / +1 charge: 每条有限次数战备 +1。
  - +2 次 / +2 charges: 每条有限次数战备 +2。
  - +3 次 / +3 charges: 每条有限次数战备 +3。
  - 去除数量限制 / unlimited: 有限次数改成无限（-1）；原本无限的不动。

The cooldown block carries the core addon and must stay enabled.
Config fine tuning: %%LOCALAPPDATA%%\CowboyBingus\Helldivers2\VehicleCooldown\config.txt
