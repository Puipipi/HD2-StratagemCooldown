战备冷却 / Stratagem Cooldown 2.2.0

默认：蓝战备＝就载具 + 冷却 80%；红/绿/次数默认关闭。
